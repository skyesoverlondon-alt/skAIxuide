(function() {
    // 1. Create the Menu HTML structure
    const navHTML = `
    <div id="suite-nav-fab" class="fixed bottom-6 right-6 z-[9999] group font-sans">
        <!-- Expanded Menu -->
        <div id="suite-nav-menu" class="absolute bottom-16 right-0 mb-2 w-56 flex flex-col gap-2 transition-all duration-300 transform scale-90 opacity-0 pointer-events-none origin-bottom-right">
            
            <a href="/skAIxuide/index.html" class="flex items-center gap-3 p-3 bg-[#0d0424]/90 backdrop-blur-xl border border-white/10 rounded-xl shadow-2xl hover:bg-indigo-900/50 hover:border-indigo-500/50 hover:scale-105 transition-all group/item text-white no-underline">
                <div class="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center shadow-lg">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                </div>
                <div>
                    <div class="font-bold text-sm leading-none mb-1">Suite Hub</div>
                    <div class="text-[10px] text-gray-400 font-mono">Main Dashboard</div>
                </div>
            </a>

            <a href="/NEWNEW/newapp.html" class="flex items-center gap-3 p-3 bg-[#0d0424]/90 backdrop-blur-xl border border-white/10 rounded-xl shadow-2xl hover:bg-cyan-900/50 hover:border-cyan-500/50 hover:scale-105 transition-all group/item text-white no-underline">
                <div class="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-500 flex items-center justify-center shadow-lg">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><line x1="12" x2="12" y1="8" y2="16"/><line x1="8" x2="16" y1="12" y2="12"/></svg>
                </div>
                <div>
                    <div class="font-bold text-sm leading-none mb-1">Nebula TaskForce</div>
                    <div class="text-[10px] text-gray-400 font-mono">Project Mgmt</div>
                </div>
            </a>

            <a href="/SkyeBox/SkyeBox.html" class="flex items-center gap-3 p-3 bg-[#0d0424]/90 backdrop-blur-xl border border-white/10 rounded-xl shadow-2xl hover:bg-purple-900/50 hover:border-purple-500/50 hover:scale-105 transition-all group/item text-white no-underline">
                 <div class="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center shadow-lg">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" x2="12" y1="22.08" y2="12"/></svg>
                </div>
                <div>
                    <div class="font-bold text-sm leading-none mb-1">SkyeBox</div>
                    <div class="text-[10px] text-gray-400 font-mono">Data Tools</div>
                </div>
            </a>

            <a href="/SkyeKnife/SkyeKnife.html" class="flex items-center gap-3 p-3 bg-[#0d0424]/90 backdrop-blur-xl border border-white/10 rounded-xl shadow-2xl hover:bg-yellow-900/50 hover:border-yellow-500/50 hover:scale-105 transition-all group/item text-white no-underline">
                 <div class="w-8 h-8 rounded-lg bg-gradient-to-br from-yellow-500 to-amber-600 flex items-center justify-center shadow-lg">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
                </div>
                <div>
                    <div class="font-bold text-sm leading-none mb-1">SkyeKnife</div>
                    <div class="text-[10px] text-gray-400 font-mono">Dev Utilities</div>
                </div>
            </a>
        </div>

        <!-- Main FAB Button -->
        <button id="suite-nav-toggle" class="w-14 h-14 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-2xl shadow-[0_0_20px_rgba(99,102,241,0.5)] flex items-center justify-center border border-white/20 hover:scale-110 active:scale-95 transition-all duration-300 z-[10000]">
            <svg id="menu-icon" class="text-white w-7 h-7 transition-all duration-300" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7" />
            </svg>
            <svg id="close-icon" class="text-white w-7 h-7 absolute opacity-0 rotate-180 transition-all duration-300" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
        </button>
    </div>
    `;

    // 2. Inject Styles (if Tailwind isn't present, these basics will help, but mostly relying on app's TW)
    // Note: Assuming all apps have Tailwind or consistent CSS.
    
    // 3. Append to Body
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = navHTML;
    document.body.appendChild(tempDiv.firstElementChild);

    // 4. Add Functionality
    const toggleBtn = document.getElementById('suite-nav-toggle');
    const menu = document.getElementById('suite-nav-menu');
    const menuIcon = document.getElementById('menu-icon');
    const closeIcon = document.getElementById('close-icon');
    let isOpen = false;

    toggleBtn.addEventListener('click', () => {
        isOpen = !isOpen;
        if (isOpen) {
            menu.classList.remove('opacity-0', 'pointer-events-none', 'scale-90', 'translate-y-4');
            menu.classList.add('opacity-100', 'scale-100', 'translate-y-0');
            
            menuIcon.classList.add('opacity-0', '-rotate-180');
            closeIcon.classList.remove('opacity-0', 'rotate-180');
        } else {
            menu.classList.add('opacity-0', 'pointer-events-none', 'scale-90', 'translate-y-4');
            menu.classList.remove('opacity-100', 'scale-100', 'translate-y-0');

            menuIcon.classList.remove('opacity-0', '-rotate-180');
            closeIcon.classList.add('opacity-0', 'rotate-180');
        }
    });

    // Close when clicking outside
    document.addEventListener('click', (e) => {
        if (isOpen && !e.target.closest('#suite-nav-fab')) {
            isOpen = false;
            menu.classList.add('opacity-0', 'pointer-events-none', 'scale-90', 'translate-y-4');
            menu.classList.remove('opacity-100', 'scale-100', 'translate-y-0');
            menuIcon.classList.remove('opacity-0', '-rotate-180');
            closeIcon.classList.add('opacity-0', 'rotate-180');
        }
    });

})();